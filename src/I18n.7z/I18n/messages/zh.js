export default {
    message: {
      hello: 'msg 世界你好'
    },
    hello: '世界你好'

  }