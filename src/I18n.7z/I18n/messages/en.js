export default {
    message: {
      hello: 'msg hello world'
    },
    hello: 'hello world'

  }